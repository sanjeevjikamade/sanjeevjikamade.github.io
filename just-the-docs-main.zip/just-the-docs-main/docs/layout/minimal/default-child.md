---
title: Default layout child page
layout: default
parent: A minimal layout page
grand_parent: Layout
---

# Default layout child page

This is a child page that uses the `default` layout as compared to its parent page (which uses the `minimal` layout).
